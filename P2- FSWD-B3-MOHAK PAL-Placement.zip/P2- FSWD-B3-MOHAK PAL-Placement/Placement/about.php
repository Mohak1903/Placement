<?php
    include "includes/header.php";
?>
		<div class="col-md-9 main" >
		<!--banner-section-->
            <div class="banner-section">
            <!--/top-news-->
            <div class="top-news">
                <div class="about-content">
                    <!-- about -->
                    <h3 class="tittle">About <i class="glyphicon glyphicon-user"></i></h3>
                    <img src="image_uploads/logo1.png" alt="" />
                    <p><b><u>Overview And Details</u></b><br><br>
                    Quient training is an enthusiastic group intended to train
                    students in colleges that are denied the privilege of Placement
                    training, A group of Enthusiasts now have a vision of training
                    students that don’t have access to placement training that can
                    help them get placed, and thereby build their future.</p>
                    <br><br>
                    <p><b><u>Why is Placement training important: <b></u><br><br>
                    Placement training plays a major role in shaping up the career goals of students. It is
                    the dream of every engineering student to get placed in a top organization visiting
                    their campus for recruitment. Keeping this key aspect into consideration, it is realized
                    that training is important for engineering students to enhance their employability skills
                    and achieve good placement in various Industries
                    At present, the competition for employment is increasing every day and placement has
                    become a challenging task. Training students and equipping them with life skills has
                    become an important responsibility of the institution. Along with technical expertise,
                    the development of a holistic personality is also necessary.
                    <br><br>
                    <p><b><u>Objectives and Training Activities by QG(Quient Group):<b></u><br>
                    The prime objective of the Training Cell is<br>
                    ● To look for 100% employment for all students.<br>
                    ● To recognize the core competencies of the students.<br>
                    ● To train the students to meet the expectations of the industry through our Career
                    Development Programmes.<br>
                    ● To build confidence in students and develop the right attitude in them and
                    ● enhance their communication skills.<br>
                    Training Activities :<br>
                    ● Create awareness about “career planning" and "career mapping" among the
                    students.<br>
                    ● Equip the student with life skills.<br>
                    ● Train the students on “Personality development".<br>
                    ● Organize Various Training Programmes to train the students in the areas of
                    Quantitative Aptitude, Logical Reasoning and Verbal reasoning through
                    the reputed external training organizations and in-house trainers.<br>
                    ● Train the students through Mock Interviews to perform well in the professional
                    interviews as per the expectations of the corporate world.<br>
                    ● Train the students on group discussion techniques<br>
                    ● Conduct online tests and written aptitude tests.</p>

                    <div class="clearfix"></div>
                </div>
                <!--div class="top-inner second">
                    <div class="col-md-6 top-text">
                        <a href="single.html"><img src="images/pic1.jpg" class="img-responsive" alt=""></a>
                        <h5 class="top"><a href="single.html">Consetetur sadipscing elit</a></h5>
                        <p>Consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt labore dolore magna aliquyam eratsed diam justo duo dolores rebum.</p>
                        <p>On Jun 25 <a class="span_link" href="#"><span class="glyphicon glyphicon-comment"></span>0 </a><a class="span_link" href="#"><span class="glyphicon glyphicon-eye-open"></span>56 </a><a class="span_link" href="single.html"><span class="glyphicon glyphicon-circle-arrow-right"></span></a></p>
                    </div>
                    <div class="col-md-6 top-text two">
                        <a href="single.html"><img src="images/pic2.jpg" class="img-responsive" alt=""></a>
                        <h5 class="top"><a href="single.html">Consetetur sadipscing elit</a></h5>
                        <p>Consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt labore dolore magna aliquyam eratsed diam justo duo dolores rebum.</p>
                        <p>On Jun 27 <a class="span_link" href="#"><span class="glyphicon glyphicon-comment"></span>0 </a><a class="span_link" href="#"><span class="glyphicon glyphicon-eye-open"></span>56 </a><a class="span_link" href="single.html"><span class="glyphicon glyphicon-circle-arrow-right"></span></a></p>
                    </div>
                    <div class="clearfix"> </div>
                </div-->
            </div>
            <!--//top-news-->
        </div>
    <!--//banner-section-->
    <div class="banner-right-text">
        <h3 class="tittle">Our Team <i class="glyphicon glyphicon-star"></i></h3>
        <!--/general-news-->
        <div class="general-news">
            <div class="general-inner">
                <div class="edit-pics">
                    <div class="editor-pics">
                        <div class="col-md-3 item-pic">
                            <img src="image_uploads/f4.jpg" class="img-responsive" alt="">

                        </div>
                        <div class="col-md-9 item-details">
                            <h5 class="inner two"><a href="#">MOHAK<br><br>ANIRUDH<br><br>PUROSHOTHAM<br><br>SURAJ</a></h5>
                            <div class="td-post-date two"></div>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    
                    </div>
                </div>
            </div>
        </div>
        <!--//general-news-->
        <!--/news-->
        <!--/news-->
    </div>
    </div>
    <div class="clearfix"> </div>
<?php
include "includes/footer.php";
?>